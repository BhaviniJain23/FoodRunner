package com.bugsTeam.training.foodrunner.model

data class MenuItemModel (
    val id:Int,
    val name:String,
    val price:Int
    )